TOOLS - NuGet Package Manager - Package Manager Console -> Install-Package MySql.Data

Export Access Database to MySQL
https://www.youtube.com/watch?v=m9LxGF3Qc90