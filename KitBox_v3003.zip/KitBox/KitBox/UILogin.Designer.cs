﻿namespace KitBox
{
    partial class UILogin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UILogin));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.panelShelf1 = new System.Windows.Forms.Panel();
            this.panelShelf2 = new System.Windows.Forms.Panel();
            this.panelShelf3 = new System.Windows.Forms.Panel();
            this.panelShelf4 = new System.Windows.Forms.Panel();
            this.panelShelf5 = new System.Windows.Forms.Panel();
            this.panelShelf6 = new System.Windows.Forms.Panel();
            this.panelShelf7 = new System.Windows.Forms.Panel();
            this.btnAddShelf = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.button6 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.panelShelf1.SuspendLayout();
            this.panelShelf2.SuspendLayout();
            this.panelShelf3.SuspendLayout();
            this.panelShelf4.SuspendLayout();
            this.panelShelf5.SuspendLayout();
            this.panelShelf6.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(201, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 37);
            this.button1.TabIndex = 45;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(330, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(64, 37);
            this.button2.TabIndex = 46;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(679, 171);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(131, 23);
            this.button3.TabIndex = 47;
            this.button3.Text = "option du meuble";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(821, 171);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(97, 23);
            this.button4.TabIndex = 48;
            this.button4.Text = "option du casier";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(679, 200);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(131, 23);
            this.button5.TabIndex = 49;
            this.button5.Text = "+ Ajouter un casier";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(676, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 50;
            this.label1.Text = "Width";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(676, 296);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 51;
            this.label2.Text = "Depth";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(821, 258);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(97, 21);
            this.comboBox1.TabIndex = 52;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(821, 296);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(97, 21);
            this.comboBox2.TabIndex = 53;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(502, 48);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(26, 23);
            this.button7.TabIndex = 55;
            this.button7.Text = "1";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(534, 48);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(26, 23);
            this.button8.TabIndex = 56;
            this.button8.Text = "2";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(566, 48);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(26, 23);
            this.button9.TabIndex = 57;
            this.button9.Text = "3";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(598, 48);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(26, 23);
            this.button10.TabIndex = 58;
            this.button10.Text = "4";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(630, 48);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(26, 23);
            this.button11.TabIndex = 60;
            this.button11.Text = ">";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(470, 48);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(26, 23);
            this.button12.TabIndex = 61;
            this.button12.Text = "<";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // panelShelf1
            // 
            this.panelShelf1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelShelf1.BackgroundImage")));
            this.panelShelf1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelShelf1.Controls.Add(this.panelShelf2);
            this.panelShelf1.Controls.Add(this.btnAddShelf);
            this.panelShelf1.Location = new System.Drawing.Point(174, 177);
            this.panelShelf1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panelShelf1.Name = "panelShelf1";
            this.panelShelf1.Size = new System.Drawing.Size(220, 520);
            this.panelShelf1.TabIndex = 62;
            this.panelShelf1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelShelf1_MouseClick);
            this.panelShelf1.MouseEnter += new System.EventHandler(this.panelShelf1_MouseEnter);
            // 
            // panelShelf2
            // 
            this.panelShelf2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelShelf2.BackgroundImage")));
            this.panelShelf2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelShelf2.Controls.Add(this.panelShelf3);
            this.panelShelf2.Location = new System.Drawing.Point(0, -65);
            this.panelShelf2.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panelShelf2.Name = "panelShelf2";
            this.panelShelf2.Size = new System.Drawing.Size(220, 520);
            this.panelShelf2.TabIndex = 11;
            this.panelShelf2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelShelf2_MouseClick);
            this.panelShelf2.MouseEnter += new System.EventHandler(this.panelShelf2_MouseEnter);
            // 
            // panelShelf3
            // 
            this.panelShelf3.BackgroundImage = global::KitBox.Properties.Resources.White_White_White;
            this.panelShelf3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelShelf3.Controls.Add(this.panelShelf4);
            this.panelShelf3.Location = new System.Drawing.Point(0, -65);
            this.panelShelf3.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panelShelf3.Name = "panelShelf3";
            this.panelShelf3.Size = new System.Drawing.Size(220, 520);
            this.panelShelf3.TabIndex = 10;
            this.panelShelf3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelShelf3_MouseClick);
            this.panelShelf3.MouseEnter += new System.EventHandler(this.panelShelf3_MouseEnter);
            // 
            // panelShelf4
            // 
            this.panelShelf4.BackgroundImage = global::KitBox.Properties.Resources.White_White_White;
            this.panelShelf4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelShelf4.Controls.Add(this.panelShelf5);
            this.panelShelf4.Location = new System.Drawing.Point(0, -65);
            this.panelShelf4.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panelShelf4.Name = "panelShelf4";
            this.panelShelf4.Size = new System.Drawing.Size(220, 520);
            this.panelShelf4.TabIndex = 10;
            this.panelShelf4.Visible = false;
            this.panelShelf4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelShelf4_MouseClick);
            this.panelShelf4.MouseEnter += new System.EventHandler(this.panelShelf4_MouseEnter);
            // 
            // panelShelf5
            // 
            this.panelShelf5.BackgroundImage = global::KitBox.Properties.Resources.White_White_White;
            this.panelShelf5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelShelf5.Controls.Add(this.panelShelf6);
            this.panelShelf5.Location = new System.Drawing.Point(0, -65);
            this.panelShelf5.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panelShelf5.Name = "panelShelf5";
            this.panelShelf5.Size = new System.Drawing.Size(220, 520);
            this.panelShelf5.TabIndex = 10;
            this.panelShelf5.Visible = false;
            this.panelShelf5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelShelf5_MouseClick);
            this.panelShelf5.MouseEnter += new System.EventHandler(this.panelShelf5_MouseEnter);
            // 
            // panelShelf6
            // 
            this.panelShelf6.BackgroundImage = global::KitBox.Properties.Resources.White_White_White;
            this.panelShelf6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelShelf6.Controls.Add(this.panelShelf7);
            this.panelShelf6.Location = new System.Drawing.Point(0, -65);
            this.panelShelf6.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panelShelf6.Name = "panelShelf6";
            this.panelShelf6.Size = new System.Drawing.Size(220, 520);
            this.panelShelf6.TabIndex = 11;
            this.panelShelf6.Visible = false;
            this.panelShelf6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelShelf6_MouseClick);
            this.panelShelf6.MouseEnter += new System.EventHandler(this.panelShelf6_MouseEnter);
            // 
            // panelShelf7
            // 
            this.panelShelf7.BackgroundImage = global::KitBox.Properties.Resources.White_White_White;
            this.panelShelf7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelShelf7.Location = new System.Drawing.Point(0, -65);
            this.panelShelf7.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.panelShelf7.Name = "panelShelf7";
            this.panelShelf7.Size = new System.Drawing.Size(220, 520);
            this.panelShelf7.TabIndex = 11;
            this.panelShelf7.Visible = false;
            this.panelShelf7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelShelf7_MouseClick);
            this.panelShelf7.MouseEnter += new System.EventHandler(this.panelShelf7_MouseEnter);
            // 
            // btnAddShelf
            // 
            this.btnAddShelf.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddShelf.FlatAppearance.BorderSize = 0;
            this.btnAddShelf.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnAddShelf.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnAddShelf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddShelf.Location = new System.Drawing.Point(82, 363);
            this.btnAddShelf.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.btnAddShelf.Name = "btnAddShelf";
            this.btnAddShelf.Size = new System.Drawing.Size(46, 46);
            this.btnAddShelf.TabIndex = 0;
            this.btnAddShelf.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(676, 344);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 13);
            this.label3.TabIndex = 63;
            this.label3.Text = "Couleur des portes :";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(198, 698);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 66;
            this.label4.Text = "Width : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(443, 670);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 67;
            this.label5.Text = "Depth : ";
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(679, 229);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(131, 23);
            this.button15.TabIndex = 68;
            this.button15.Text = "- Supprimer un casier";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(443, 610);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 13);
            this.label6.TabIndex = 69;
            this.label6.Text = "32";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(443, 540);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(19, 13);
            this.label7.TabIndex = 70;
            this.label7.Text = "32";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(443, 466);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 13);
            this.label8.TabIndex = 71;
            this.label8.Text = "32";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(443, 412);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 13);
            this.label9.TabIndex = 72;
            this.label9.Text = "32";
            this.label9.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(443, 341);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(19, 13);
            this.label10.TabIndex = 73;
            this.label10.Text = "32";
            this.label10.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(443, 266);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(19, 13);
            this.label11.TabIndex = 74;
            this.label11.Text = "32";
            this.label11.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(443, 200);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(19, 13);
            this.label12.TabIndex = 75;
            this.label12.Text = "32";
            this.label12.Visible = false;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "White",
            "Brown",
            "Glass"});
            this.comboBox3.Location = new System.Drawing.Point(821, 341);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(97, 21);
            this.comboBox3.TabIndex = 76;
            this.comboBox3.Text = "Gauche";
            this.comboBox3.Visible = false;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "White",
            "Brown",
            "Glass"});
            this.comboBox4.Location = new System.Drawing.Point(946, 341);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(97, 21);
            this.comboBox4.TabIndex = 77;
            this.comboBox4.Text = "Droite";
            this.comboBox4.Visible = false;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(679, 412);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 78;
            this.button6.Text = "valide";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(924, 261);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(112, 13);
            this.label13.TabIndex = 79;
            this.label13.Text = "No doors for this width";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(676, 385);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(115, 13);
            this.label14.TabIndex = 80;
            this.label14.Text = "Couleur des cornières :";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "White",
            "Brown",
            "Galvanized",
            "Black"});
            this.comboBox5.Location = new System.Drawing.Point(821, 385);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(97, 21);
            this.comboBox5.TabIndex = 81;
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // UILogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.BackgroundImage = global::KitBox.Properties.Resources.view_11;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panelShelf1);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "UILogin";
            this.Size = new System.Drawing.Size(1280, 800);
            this.Load += new System.EventHandler(this.UILogin_Load);
            this.panelShelf1.ResumeLayout(false);
            this.panelShelf2.ResumeLayout(false);
            this.panelShelf3.ResumeLayout(false);
            this.panelShelf4.ResumeLayout(false);
            this.panelShelf5.ResumeLayout(false);
            this.panelShelf6.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Panel panelShelf1;
        private System.Windows.Forms.Panel panelShelf2;
        private System.Windows.Forms.Panel panelShelf3;
        private System.Windows.Forms.Panel panelShelf4;
        private System.Windows.Forms.Panel panelShelf5;
        private System.Windows.Forms.Panel panelShelf6;
        private System.Windows.Forms.Panel panelShelf7;
        private System.Windows.Forms.Button btnAddShelf;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox5;
    }
}
