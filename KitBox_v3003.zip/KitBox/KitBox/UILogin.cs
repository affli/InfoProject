﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KitBox
{
    public partial class UILogin : UserControl
    {
        Dictionary<string, string> items = new Dictionary<string, string>();
        bool button4__Click = false;
        int num_casier = 1;
        int nombre_casiers = 3;

        public UILogin()
        {
            InitializeComponent();
        }

        private void UILogin_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("32");
            comboBox1.Items.Add("42");
            comboBox1.Items.Add("52");
            comboBox1.Items.Add("62");
            comboBox1.Items.Add("80");
            comboBox1.Items.Add("100");
            comboBox1.Items.Add("120");

            comboBox2.Items.Add("32");
            comboBox2.Items.Add("42");
            comboBox2.Items.Add("52");
            comboBox2.Items.Add("62");

            items.Add("Largeur", "62");
            items.Add("Profendeur", "32");
            items.Add("Couleur_Cornières", "White");

            if (items["Largeur"] != "32" || items["Largeur"] != "42" || items["Largeur"] != "52")
            {
                for (int i = 1; i <= nombre_casiers; i++)
                {
                    items.Add("Hauteur_" + i, "32");
                    items.Add("Couleur_casier_" + i, "White");
                    items.Add("CouleurG_" + i, "White");
                    items.Add("CouleurD_" + i, "White");
                }
            }
            else
            {
                for (int i = 1; i <= nombre_casiers; i++)
                {
                    items.Add("Hauteur_" + i, "32");
                    items.Add("Couleur_casier_" + i, "White");
                }
            }

            comboBox1.SelectedIndex = 3;
            comboBox2.SelectedIndex = 0;
            comboBox5.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = null;
            this.Controls.Clear();
            this.Controls.Add(new LaunchScreen());
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (button7.Text == "1")
            {
                button7.Text = "2";
                button8.Text = "3";
                button9.Text = "4";
                button10.Text = "5";
            }

            else if (button7.Text == "2")
            {
                button7.Text = "3";
                button8.Text = "4";
                button9.Text = "5";
                button10.Text = "6";
            }

            else if (button7.Text == "3")
            {
                button7.Text = "4";
                button8.Text = "5";
                button9.Text = "6";
                button10.Text = "7";
            }

        }

        private void button12_Click(object sender, EventArgs e)
        {

            if (button7.Text == "2")
            {
                button7.Text = "1";
                button8.Text = "2";
                button9.Text = "3";
                button10.Text = "4";
            }

            else if (button7.Text == "3")
            {
                button7.Text = "2";
                button8.Text = "3";
                button9.Text = "4";
                button10.Text = "5";
            }

            else if (button7.Text == "4")
            {
                button7.Text = "3";
                button8.Text = "4";
                button9.Text = "5";
                button10.Text = "6";
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (button7.Text == "1")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = false;
                panelShelf3.Visible = false;
                panelShelf4.Visible = false;
                panelShelf5.Visible = false;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = false;
                label8.Visible = false;
                label9.Visible = false;
                label10.Visible = false;
                label11.Visible = false;
                label12.Visible = false;
            }

            else if (button7.Text == "2")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = false;
                panelShelf4.Visible = false;
                panelShelf5.Visible = false;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = false;
                label9.Visible = false;
                label10.Visible = false;
                label11.Visible = false;
                label12.Visible = false;
            }

            else if (button7.Text == "3")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = false;
                panelShelf5.Visible = false;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = false;
                label10.Visible = false;
                label11.Visible = false;
                label12.Visible = false;
            }

            else if (button7.Text == "4")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = true;
                panelShelf5.Visible = false;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = false;
                label11.Visible = false;
                label12.Visible = false;


                nombre_casiers = 4;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }

                test();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (button8.Text == "2")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = false;
                panelShelf4.Visible = false;
                panelShelf5.Visible = false;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = false;
                label9.Visible = false;
                label10.Visible = false;
                label11.Visible = false;
                label12.Visible = false;
            }

            else if (button8.Text == "3")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = false;
                panelShelf5.Visible = false;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = false;
                label10.Visible = false;
                label11.Visible = false;
                label12.Visible = false;
            }

            else if (button8.Text == "4")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = true;
                panelShelf5.Visible = false;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = false;
                label11.Visible = false;
                label12.Visible = false;

                nombre_casiers = 4;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                test();
            }

            else if (button8.Text == "5")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = true;
                panelShelf5.Visible = true;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = true;
                label11.Visible = false;
                label12.Visible = false;

                nombre_casiers = 4;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }

                nombre_casiers = 5;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                test();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (button9.Text == "3")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = false;
                panelShelf5.Visible = false;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = false;
                label10.Visible = false;
                label11.Visible = false;
                label12.Visible = false;
            }

            else if (button9.Text == "4")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = true;
                panelShelf5.Visible = false;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = false;
                label11.Visible = false;
                label12.Visible = false;

                nombre_casiers = 4;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                test();

            }

            else if (button9.Text == "5")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = true;
                panelShelf5.Visible = true;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = true;
                label11.Visible = false;
                label12.Visible = false;

                nombre_casiers = 4;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }

                nombre_casiers = 5;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                test();
            }

            else if (button9.Text == "6")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = true;
                panelShelf5.Visible = true;
                panelShelf6.Visible = true;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = true;
                label11.Visible = true;
                label12.Visible = false;

                nombre_casiers = 4;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }

                nombre_casiers = 5;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                nombre_casiers = 6;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                test();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (button10.Text == "4")
            {
                

                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = true;
                panelShelf5.Visible = false;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = false;
                label11.Visible = false;
                label12.Visible = false;

                nombre_casiers = 4;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                test();

            }

            else if (button10.Text == "5")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = true;
                panelShelf5.Visible = true;
                panelShelf6.Visible = false;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = true;
                label11.Visible = false;
                label12.Visible = false;

                nombre_casiers = 4;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }

                nombre_casiers = 5;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                test();
            }

            else if (button10.Text == "6")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = true;
                panelShelf5.Visible = true;
                panelShelf6.Visible = true;
                panelShelf7.Visible = false;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = true;
                label11.Visible = true;
                label12.Visible = false;

                nombre_casiers = 4;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                nombre_casiers = 5;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                nombre_casiers = 6;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                test();
            }

            else if (button10.Text == "7")
            {
                panelShelf1.Visible = true;
                panelShelf2.Visible = true;
                panelShelf3.Visible = true;
                panelShelf4.Visible = true;
                panelShelf5.Visible = true;
                panelShelf6.Visible = true;
                panelShelf7.Visible = true;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;
                label9.Visible = true;
                label10.Visible = true;
                label11.Visible = true;
                label12.Visible = true;

                nombre_casiers = 4;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                nombre_casiers = 5;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                nombre_casiers = 6;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                nombre_casiers = 7;
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {
                    //
                }

                else
                {
                    if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                    }
                    else
                    {
                        items.Add("Hauteur_" + nombre_casiers, "32");
                        items.Add("Couleur_casier_" + nombre_casiers, "White");
                        items.Add("CouleurD_" + nombre_casiers, "White");
                        items.Add("CouleurG_" + nombre_casiers, "White");
                    }
                }
                test();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = "Width";
            label2.Text = "Depth";

            comboBox3.Visible = false;
            comboBox4.Visible = false;
            button5.Visible = true;
            comboBox2.Visible = true;
            label3.Visible = false;
            button15.Visible = true;
            button4__Click = false;
            button5.Text = "+ Ajouter un casier";

            label14.Visible = true;
            comboBox5.Visible = true;

            comboBox2.Items.Clear();
            comboBox2.Items.Add("32");
            comboBox2.Items.Add("42");
            comboBox2.Items.Add("52");
            comboBox2.Items.Add("62");

            comboBox1.Items.Clear();
            comboBox1.Items.Add("32");
            comboBox1.Items.Add("42");
            comboBox1.Items.Add("52");
            comboBox1.Items.Add("62");
            comboBox1.Items.Add("80");
            comboBox1.Items.Add("100");
            comboBox1.Items.Add("120");

            if (items.ContainsKey("Largeur"))
            {
                comboBox1.Text = items["Largeur"];
            }
            else
            {
                comboBox1.Text = "62";
            }

            if (items.ContainsKey("Profendeur"))
            {
                comboBox2.Text = items["Profendeur"];
            }
            else
            {
                comboBox2.Text = "32";
            }
            test();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4__Click = true;

            label1.Text = "Hauteur du casier";
            label2.Text = "Couleur du casier :";
            button5.Text = "- Supprimer le casier";
            button15.Visible = false;

            label14.Visible = false;
            comboBox5.Visible = false;

            if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
            {
                label3.Visible = false;
                comboBox3.Visible = false;
                comboBox4.Visible = false;
            }
            else
            {
                label3.Visible = true;
                comboBox3.Visible = true;
                comboBox4.Visible = true;
            }

            comboBox1.Items.Clear();
            comboBox1.Items.Add("32");
            comboBox1.Items.Add("42");
            comboBox1.Items.Add("52");

            comboBox2.Items.Clear();
            comboBox2.Items.Add("White");
            comboBox2.Items.Add("Brown");

            comboBox2.Text = "White";
            comboBox1.SelectedIndex = 0;
            //comboBox2.SelectedIndex = 0;
            //comboBox3.SelectedIndex = 0;
            //comboBox4.SelectedIndex = 0;

            test();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (button4__Click == false)
            {
                label4.Text = "Width : " + comboBox1.Text;

                if (items.ContainsKey("Largeur") && label1.Text == "Width")
                {
                    items["Largeur"] = comboBox1.Text;
                }

                else if(label1.Text == "Width")
                {
                    items.Add("Largeur", comboBox1.Text);
                }

                if (comboBox1.Text == "32" || comboBox1.Text == "42" || comboBox1.Text == "52")
                {

                    if (items.ContainsKey("Largeur") && label1.Text == "Width")
                    {
                        items["Largeur"] = comboBox1.Text;
                    }

                    else if (label1.Text == "Width")
                    {
                        items.Add("Largeur", comboBox1.Text);
                    }

                    for(int i = 1; i <= nombre_casiers; i++)
                    {
                        items.Remove("CouleurD_" + i);
                        items.Remove("CouleurG_" + i);
                    }

                    label13.Text = "No doors for this width";
                    test();
                }
                else
                {
                    for (int i = 1; i <= nombre_casiers; i++)
                    {
                        if (items.ContainsKey("CouleurG_" + i) && label1.Text == "Width")
                        {
                        }

                        else if (label1.Text == "Width")
                        {
                            items.Add("CouleurG_" + i, "White");
                            items.Add("CouleurD_" + i, "White");
                        }
                    }

                    label13.Text = "";
                    test();
                }
            }

            if(button4__Click == true)
            {
                if (items.ContainsKey("Hauteur_" + num_casier) && label1.Text == "Hauteur du casier")
                {
                    items["Hauteur_" + num_casier] = comboBox1.Text;
                }

                else if (label1.Text == "Hauteur du casier")
                {
                    items.Add("Hauteur_" + num_casier, comboBox1.Text);
                }

                if (num_casier == 1)
                {
                    label6.Text = comboBox1.Text;
                }

                if (num_casier == 2)
                {
                    label7.Text = comboBox1.Text;
                }
                if (num_casier == 3)
                {
                    label8.Text = comboBox1.Text;
                }
                if (num_casier == 4)
                {
                    label9.Visible = true;
                    label9.Text = comboBox1.Text;
                }
                if (num_casier == 5)
                {
                    label10.Visible = true;
                    label10.Text = comboBox1.Text;
                }
                if (num_casier == 6)
                {
                    label11.Visible = true;
                    label11.Text = comboBox1.Text;
                }
                if (num_casier == 7)
                {
                    label12.Visible = true;
                    label12.Text = comboBox1.Text;
                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (button4__Click == false)
            {
                label5.Text = "Depth : " + comboBox2.Text;

                if (items.ContainsKey("Profendeur"))
                {
                    items["Profendeur"] = comboBox2.Text;
                }

                else
                {
                    items.Add("Profendeur", comboBox2.Text);
                }
            }

            else if (button4__Click == true)
            {
                if (items.ContainsKey("Couleur_casier_" + num_casier))
                {
                    items["Couleur_casier_" + num_casier] = comboBox2.Text;
                }

                else
                {
                    items.Add("Couleur_casier_" + num_casier, comboBox2.Text);
                }

                test();
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (items.ContainsKey("CouleurG_" + num_casier))
            {
                items["CouleurG_" + num_casier] = comboBox3.Text;
            }

            else
            {
                items.Add("CouleurG_" + num_casier, comboBox3.Text);
            }

            test();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (items.ContainsKey("CouleurD_" + num_casier))
            {
                items["CouleurD_" + num_casier] = comboBox4.Text;
            }

            else
            {
                items.Add("CouleurD_" + num_casier, comboBox4.Text);
            }

            test();
        }

        private void panelShelf1_MouseClick(object sender, MouseEventArgs e)
        {
            num_casier = 1;
            test();

        }

        private void panelShelf2_MouseClick(object sender, MouseEventArgs e)
        {
            num_casier = 2;
            test();
        }

        private void panelShelf3_MouseClick(object sender, MouseEventArgs e)
        {
            num_casier = 3;
            test();
        }

        private void panelShelf4_MouseClick(object sender, MouseEventArgs e)
        {
            num_casier = 4;
            test();
        }

        private void panelShelf5_MouseClick(object sender, MouseEventArgs e)
        {
            num_casier = 5;
            test();
        }

        private void panelShelf6_MouseClick(object sender, MouseEventArgs e)
        {
            num_casier = 6;
            test();
        }

        private void panelShelf7_MouseClick(object sender, MouseEventArgs e)
        {
            num_casier = 7;
            test();
        }

        private void panelShelf1_MouseEnter(object sender, EventArgs e)
        {
            if (button4__Click == true)
            {
                panelShelf1.Cursor = Cursors.Hand;
            }
            else
            {
                panelShelf1.Cursor = Cursors.Default;
            }
        }

        private void panelShelf2_MouseEnter(object sender, EventArgs e)
        {
            if (button4__Click == true)
            {
                panelShelf2.Cursor = Cursors.Hand;
            }
            else
            {
                panelShelf2.Cursor = Cursors.Default;
            }

        }

        private void panelShelf3_MouseEnter(object sender, EventArgs e)
        {
            if (button4__Click == true)
            {
                panelShelf3.Cursor = Cursors.Hand;
            }
            else
            {
                panelShelf3.Cursor = Cursors.Default;
            }
        }

        private void panelShelf4_MouseEnter(object sender, EventArgs e)
        {
            if (button4__Click == true)
            {
                panelShelf4.Cursor = Cursors.Hand;
            }
            else
            {
                panelShelf4.Cursor = Cursors.Default;
            }
        }

        private void panelShelf5_MouseEnter(object sender, EventArgs e)
        {
            if (button4__Click == true)
            {
                panelShelf5.Cursor = Cursors.Hand;
            }
            else
            {
                panelShelf5.Cursor = Cursors.Default;
            }
        }

        private void panelShelf6_MouseEnter(object sender, EventArgs e)
        {
            if (button4__Click == true)
            {
                panelShelf6.Cursor = Cursors.Hand;
            }
            else
            {
                panelShelf6.Cursor = Cursors.Default;
            }
        }

        private void panelShelf7_MouseEnter(object sender, EventArgs e)
        {
            if (button4__Click == true)
            {
                panelShelf7.Cursor = Cursors.Hand;
            }
            else
            {
                panelShelf7.Cursor = Cursors.Default;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (nombre_casiers == 1)
            {
                panelShelf2.Visible = true;
                label7.Visible = true;
                nombre_casiers = 2;
            }

            else if (nombre_casiers == 2)
            {
                panelShelf3.Visible = true;
                label8.Visible = true;
                nombre_casiers = 3;
            }

            else if (nombre_casiers == 3)
            {
                panelShelf4.Visible = true;
                label9.Visible = true;
                nombre_casiers = 4;




            }

            else if (nombre_casiers == 4)
            {
                panelShelf5.Visible = true;
                label10.Visible = true;
                nombre_casiers = 5;

            }

            else if (nombre_casiers == 5)
            {
                panelShelf6.Visible = true;
                label11.Visible = true;
                nombre_casiers = 6;



            }

            else if (nombre_casiers == 6)
            {
                panelShelf7.Visible = true;
                label12.Visible = true;
                nombre_casiers = 7;
                
            }

            if (items["Largeur"] == "32" || items["Largeur"] == "42" || items["Largeur"] == "52")
            {
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {

                }

                else
                {
                    items.Add("Hauteur_" + nombre_casiers, "32");
                    items.Add("Couleur_casier_" + nombre_casiers, "White");
                }

            }
            else
            {
                if (items.ContainsKey("Hauteur_" + nombre_casiers))
                {

                }

                else
                {
                    items.Add("Hauteur_" + nombre_casiers, "32");
                    items.Add("Couleur_casier_" + nombre_casiers, "White");
                    items.Add("CouleurD_" + nombre_casiers, "White");
                    items.Add("CouleurG_" + nombre_casiers, "White");
                }

            }
            test();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (nombre_casiers == 7)
            {
                items.Remove("Hauteur_" + nombre_casiers);
                items.Remove("Couleur_casier_" + nombre_casiers);
                items.Remove("CouleurD_" + nombre_casiers);
                items.Remove("CouleurG_" + nombre_casiers);

                panelShelf7.Visible = false;
                label12.Visible = false;
                nombre_casiers = 6;
            }

            else if (nombre_casiers == 6)
            {
                items.Remove("Hauteur_" + nombre_casiers);
                items.Remove("Couleur_casier_" + nombre_casiers);
                items.Remove("CouleurD_" + nombre_casiers);
                items.Remove("CouleurG_" + nombre_casiers);

                panelShelf6.Visible = false;
                label11.Visible = false;
                nombre_casiers = 5;
            }

            else if (nombre_casiers == 5)
            {
                items.Remove("Hauteur_" + nombre_casiers);
                items.Remove("Couleur_casier_" + nombre_casiers);
                items.Remove("CouleurD_" + nombre_casiers);
                items.Remove("CouleurG_" + nombre_casiers);

                panelShelf5.Visible = false;
                label10.Visible = false;
                nombre_casiers = 4;
            }

            else if (nombre_casiers == 4)
            {
                items.Remove("Hauteur_" + nombre_casiers);
                items.Remove("Couleur_casier_" + nombre_casiers);
                items.Remove("CouleurD_" + nombre_casiers);
                items.Remove("CouleurG_" + nombre_casiers);

                panelShelf4.Visible = false;
                label9.Visible = false;
                nombre_casiers = 3;
            }

            else if (nombre_casiers == 3)
            {
                items.Remove("Hauteur_" + nombre_casiers);
                items.Remove("Couleur_casier_" + nombre_casiers);
                items.Remove("CouleurD_" + nombre_casiers);
                items.Remove("CouleurG_" + nombre_casiers);

                nombre_casiers = 2;
                panelShelf3.Visible = false;
                label8.Visible = false;
            }

            else if (nombre_casiers == 2)
            {
                items.Remove("Hauteur_" + nombre_casiers);
                items.Remove("Couleur_casier_" + nombre_casiers);
                items.Remove("CouleurD_" + nombre_casiers);
                items.Remove("CouleurG_" + nombre_casiers);

                panelShelf2.Visible = false;
                label7.Visible = false;
                nombre_casiers = 1;
            }

        }

        private void test()
        {
            if (button4__Click == true)
            {
                for (int i = 1; i <= nombre_casiers; i++)
                {
                    if (items.ContainsKey("Couleur_casier_" + i) && items.ContainsKey("CouleurG_" + i) && items.ContainsKey("CouleurD_" + i))
                    {
                        object O = Properties.Resources.ResourceManager.GetObject(items["Couleur_casier_" + i] + "_" + items["CouleurG_" + i] + "_"
                            + items["CouleurD_" + i] + "_1");

                        this.Controls.Find("panelShelf" + i, true)[0].BackgroundImage = (Image)O;
                    }

                    else
                    {
                        if (items.ContainsKey("Couleur_casier_" + i))
                        {
                            object O = Properties.Resources.ResourceManager.GetObject(items["Couleur_casier_" + i] + "_1");

                            this.Controls.Find("panelShelf" + i, true)[0].BackgroundImage = (Image)O;
                        }
                    }
                }

                if (items.ContainsKey("Couleur_casier_" + num_casier) && items.ContainsKey("CouleurG_" + num_casier) && items.ContainsKey("CouleurD_" + num_casier))
                {
                    object O = Properties.Resources.ResourceManager.GetObject(items["Couleur_casier_" + num_casier] + "_" + items["CouleurG_" + num_casier] + "_"
                        + items["CouleurD_" + num_casier]);

                    this.Controls.Find("panelShelf" + num_casier, true)[0].BackgroundImage = (Image)O;


                }

                else
                {
                    if (items.ContainsKey("Couleur_casier_" + num_casier) )
                    {
                        object O = Properties.Resources.ResourceManager.GetObject(items["Couleur_casier_" + num_casier]);

                        this.Controls.Find("panelShelf" + num_casier, true)[0].BackgroundImage = (Image)O;
                    }
                }

                if (items.ContainsKey("Hauteur_" + num_casier))
                {
                    comboBox1.Text = items["Hauteur_" + num_casier];
                }
                else
                {
                    comboBox1.Text = "32";
                }
            }

            else
            {
                for (int i = 1; i <= nombre_casiers; i++)
                {
                    if (items.ContainsKey("Couleur_casier_" + i) && items.ContainsKey("CouleurG_" + i) && items.ContainsKey("CouleurD_" + i))
                    {
                        object O = Properties.Resources.ResourceManager.GetObject(items["Couleur_casier_" + i] + "_" + items["CouleurG_" + i] + "_"
                            + items["CouleurD_" + i]);

                        this.Controls.Find("panelShelf" + i, true)[0].BackgroundImage = (Image)O;  
                    }

                    else
                    {
                        object O = Properties.Resources.ResourceManager.GetObject(items["Couleur_casier_" + i]);

                        this.Controls.Find("panelShelf" + i, true)[0].BackgroundImage = (Image)O;
                    }
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = null;
            this.Controls.Clear();
            this.Controls.Add(new UIValidate(items, nombre_casiers));
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (items.ContainsKey("Couleur_Cornières"))
            {
                items["Couleur_Cornières"] = comboBox5.Text;
            }

            else
            {
                items.Add("Couleur_Cornières", comboBox5.Text);
            }
        }
    }
}
