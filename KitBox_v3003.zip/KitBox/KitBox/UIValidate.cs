﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.IO;
using MySql.Data.MySqlClient;

namespace KitBox
{
    public partial class UIValidate : UserControl
    {
        #region Functions

        Dictionary<string, string> items = new Dictionary<string, string>();
        int nombre_casiers;
        string solutionpath = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(Directory.GetCurrentDirectory())));

        public UIValidate(Dictionary<string, string> items, int nombre_casiers)
        {
            this.items = items;
            this.nombre_casiers = nombre_casiers;
            InitializeComponent();
        }

        private void UIValidate_Load(object sender, EventArgs e)
        {
            label1.Text = "";

            foreach (KeyValuePair<string, string> kvp in items)
            {
                label1.Text += string.Format("{0}, {1}" + "\n", kvp.Key, kvp.Value);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int i = 1;
                DataTable dtbl = MakeDataTable();
                string test = solutionpath + "\\KitBox\\bin\\Debug\\Bills\\bill_" + i + ".pdf";
                i += 1;

                ExportDataTableToPdf(dtbl, @test, "Order Sheet");
                if (checkBox1.Checked)
                {
                    System.Diagnostics.Process.Start(@test);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        string color_code_G = null;
        string color_code_D = null;
        string price = "";
        double total_price = 0;

        string code_couleur_casier = null;

        DataTable MakeDataTable()
        {
            //Create bill table object
            DataTable bill = new DataTable();

            //Define columns
            bill.Columns.Add("Cabinet No");
            bill.Columns.Add("Product Id");
            bill.Columns.Add("Product");
            bill.Columns.Add("Price (€)");
            bill.Columns.Add("Quantity");
            bill.Columns.Add("Total");

            for (int i = 1; i <= nombre_casiers; i++)
            {
                if(items.ContainsKey("CouleurG_" + i) || items.ContainsKey("CouleurD_" + i))
                {
                    if (items["CouleurG_" + i] == "White")
                        color_code_G = "BL";

                    if (items["CouleurG_" + i] == "Brown")
                        color_code_G = "BR";
                    if (items["CouleurG_" + i] == "Glass")
                        color_code_G = "VE";

                    if (items["CouleurD_" + i] == "White")
                        color_code_D = "BL";
                    if (items["CouleurD_" + i] == "Brown")
                        color_code_D = "BR";
                    if (items["CouleurD_" + i] == "Glass")
                        color_code_D = "VE";
                }


                string code_largeur_porte = null;

                if(items["Largeur"] == "62")
                {
                    code_largeur_porte = "32";
                }
                else
                {
                    code_largeur_porte = (Convert.ToInt32(items["Largeur"]) / 2 + 2).ToString();
                }

                if (items["Couleur_casier_" + i] == "White")
                    code_couleur_casier = "BL";
                else if (items["Couleur_casier_" + i] == "Brown")
                    code_couleur_casier = "BR";

                //Add Left Door
                if (items.ContainsKey("Hauteur_" + i) && items.ContainsKey("Largeur") && items.ContainsKey("CouleurG_" + i) && items["Largeur"] != "32" && items["Largeur"] != "42" && items["Largeur"] != "52")
                {
                    MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = catalogue;");
                    connection.Open();
                    MySqlCommand sqlCmd1 = new MySqlCommand("SELECT Prix_Client FROM porte WHERE Code=" + "'POR" + items["Hauteur_" + i] + code_largeur_porte + color_code_G + "'", connection);
                    MySqlDataReader myReader1 = sqlCmd1.ExecuteReader();

                    while (myReader1.Read())
                    {
                        price = myReader1.GetString(0);
                        price = Math.Round(Convert.ToDouble(price), 2).ToString("0.00").ToString();

                        total_price += Convert.ToDouble(price);
                        total_price = Convert.ToDouble(Math.Round(total_price, 2).ToString("0.00"));
                    }
                    connection.Close();

                    bill.Rows.Add(i, "POR" + items["Hauteur_" + i] + code_largeur_porte + color_code_G, "Porte Gauche", price, 1, price);
                }

                //Add Right Door
                if (items.ContainsKey("Hauteur_" + i) && items.ContainsKey("Largeur") && items.ContainsKey("CouleurD_" + i) && items["Largeur"] != "32" && items["Largeur"] != "42" && items["Largeur"] != "52")
                {
                    MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = catalogue;");
                    connection.Open();
                    MySqlCommand sqlCmd1 = new MySqlCommand("SELECT Prix_Client FROM porte WHERE Code=" + "'POR" + items["Hauteur_" + i] + code_largeur_porte + color_code_D + "'", connection);
                    MySqlDataReader myReader1 = sqlCmd1.ExecuteReader();

                    while (myReader1.Read())
                    {
                        price = myReader1.GetString(0);
                        price = Math.Round(Convert.ToDouble(price), 2).ToString("0.00").ToString();

                        total_price += Convert.ToDouble(price);
                        total_price = Convert.ToDouble(Math.Round(total_price, 2).ToString("0.00"));
                    }
                    connection.Close();

                    bill.Rows.Add(i, "POR" + items["Hauteur_" + i] + code_largeur_porte + color_code_D, "Porte Droite", price, 1, price);
                }

                //Add COUPEL
                if (color_code_G != "VE" && color_code_D != "VE")
                {
                    bill.Rows.Add(i, "COUPEL", "Coupelles", "0,01", 2, 0.02 * 2);
                }

                else if (color_code_G != "VE" && color_code_D == "VE" || color_code_D != "VE" && color_code_G == "VE")
                {
                    bill.Rows.Add(i, "COUPEL", "Coupelles", "0,01", 1, 0.01 * 1);
                }

                //Add Panneau AR
                if (items.ContainsKey("Hauteur_" + i) && items.ContainsKey("Largeur") && items.ContainsKey("Couleur_casier_" + i))
                {
                    MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = catalogue;");
                    connection.Open();
                    MySqlCommand sqlCmd1 = new MySqlCommand("SELECT Prix_Client FROM panneau_ar WHERE Code=" + "'PAR" + items["Hauteur_" + i] + items["Largeur"] + code_couleur_casier + "'", connection);
                    MySqlDataReader myReader1 = sqlCmd1.ExecuteReader();

                    while (myReader1.Read())
                    {
                        price = myReader1.GetString(0);
                        price = Math.Round(Convert.ToDouble(price), 2).ToString("0.00").ToString();

                        total_price += Convert.ToDouble(price);
                        total_price = Convert.ToDouble(Math.Round(total_price, 2).ToString("0.00"));
                    }
                    connection.Close();

                    bill.Rows.Add(i, "PAR" + items["Hauteur_" + i] + items["Largeur"] + code_couleur_casier, "Panneau Ar", price, 1, price);
                }

                //Add Panneau GD PAG
                if (items.ContainsKey("Hauteur_" + i) && items.ContainsKey("Largeur") && items.ContainsKey("Couleur_casier_" + i))
                {
                    MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = catalogue;");
                    connection.Open();
                    MySqlCommand sqlCmd1 = new MySqlCommand("SELECT Prix_Client FROM panneau_gd WHERE Code=" + "'PAG" + items["Hauteur_" + i] + items["Largeur"] + code_couleur_casier + "'", connection);
                    MySqlDataReader myReader1 = sqlCmd1.ExecuteReader();

                    while (myReader1.Read())
                    {
                        price = myReader1.GetString(0);
                        price = Math.Round(Convert.ToDouble(price), 2).ToString("0.00").ToString();

                        total_price += Convert.ToDouble(price);
                        total_price = Convert.ToDouble(Math.Round(total_price, 2).ToString("0.00"));
                    }
                    connection.Close();

                    bill.Rows.Add(i, "PAG" + items["Hauteur_" + i] + items["Largeur"] + code_couleur_casier, "Panneau GD", price, 2, 2 * Convert.ToDouble(price));
                }

                //Add Panneau HB PAH
                if (items.ContainsKey("Hauteur_" + i) && items.ContainsKey("Largeur") && items.ContainsKey("Couleur_casier_" + i))
                {
                    MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = catalogue;");
                    connection.Open();
                    MySqlCommand sqlCmd1 = new MySqlCommand("SELECT Prix_Client FROM panneau_hb WHERE Code=" + "'PAH" + items["Hauteur_" + i] + items["Largeur"] + code_couleur_casier + "'", connection);
                    MySqlDataReader myReader1 = sqlCmd1.ExecuteReader();

                    while (myReader1.Read())
                    {
                        price = myReader1.GetString(0);
                        price = Math.Round(Convert.ToDouble(price), 2).ToString("0.00").ToString();

                        total_price += Convert.ToDouble(price);
                        total_price = Convert.ToDouble(Math.Round(total_price, 2).ToString("0.00"));
                    }
                    connection.Close();

                    bill.Rows.Add(i, "PAH" + items["Hauteur_" + i] + items["Largeur"] + code_couleur_casier, "Panneau HB", price, 2, 2 * Convert.ToDouble(price));
                }

                //Add Tasseau TAS
                if (items.ContainsKey("Hauteur_" + i) && items.ContainsKey("Largeur") && items.ContainsKey("Couleur_casier_" + i))
                {
                    MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = catalogue;");
                    connection.Open();
                    MySqlCommand sqlCmd1 = new MySqlCommand("SELECT Prix_Client FROM tasseau WHERE Code=" + "'TAS" + (Convert.ToInt32(items["Hauteur_" + i]) - 5).ToString() + "'", connection);
                    MySqlDataReader myReader1 = sqlCmd1.ExecuteReader();

                    while (myReader1.Read())
                    {
                        price = myReader1.GetString(0);
                        price = Math.Round(Convert.ToDouble(price), 2).ToString("0.00").ToString();

                        total_price += Convert.ToDouble(price);
                        total_price = Convert.ToDouble(Math.Round(total_price, 2).ToString("0.00"));
                    }
                    connection.Close();

                    bill.Rows.Add(i, "TAS" + (Convert.ToInt32(items["Hauteur_" + i]) - 5).ToString(), "Tasseau", price, 4, 4 * Convert.ToDouble(price));
                }

                //Add Traverse GD TRG
                if (items.ContainsKey("Hauteur_" + i) && items.ContainsKey("Largeur") && items.ContainsKey("Couleur_casier_" + i))
                {
                    MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = catalogue;");
                    connection.Open();
                    MySqlCommand sqlCmd1 = new MySqlCommand("SELECT Prix_Client FROM traverse_gd WHERE Code=" + "'TRG" + items["Profendeur"] + "'", connection);
                    MySqlDataReader myReader1 = sqlCmd1.ExecuteReader();

                    while (myReader1.Read())
                    {
                        price = myReader1.GetString(0);
                        price = Math.Round(Convert.ToDouble(price), 2).ToString("0.00").ToString();

                        total_price += Convert.ToDouble(price);
                        total_price = Convert.ToDouble(Math.Round(total_price, 2).ToString("0.00"));
                    }
                    connection.Close();

                    bill.Rows.Add(i, "TRG" + items["Profendeur"], "Traverse GD", price, 4, 4* Convert.ToDouble(price));
                }

                //Add Traverse AR TRR
                if (items.ContainsKey("Hauteur_" + i) && items.ContainsKey("Largeur") && items.ContainsKey("Couleur_casier_" + i))
                {
                    MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = catalogue;");
                    connection.Open();
                    MySqlCommand sqlCmd1 = new MySqlCommand("SELECT Prix_Client FROM traverse_ar WHERE Code=" + "'TRR" + items["Largeur"] + "'", connection);
                    MySqlDataReader myReader1 = sqlCmd1.ExecuteReader();

                    while (myReader1.Read())
                    {
                        price = myReader1.GetString(0);
                        price = Math.Round(Convert.ToDouble(price), 2).ToString("0.00").ToString();

                        total_price += Convert.ToDouble(price);
                        total_price = Convert.ToDouble(Math.Round(total_price, 2).ToString("0.00"));
                    }
                    connection.Close();

                    bill.Rows.Add(i, "TRR" + items["Largeur"], "Traverse AR", price, 2, 2 * Convert.ToDouble(price));
                }

                //Add Traverse AV TRF
                if (items.ContainsKey("Hauteur_" + i) && items.ContainsKey("Largeur") && items.ContainsKey("Couleur_casier_" + i))
                {
                    MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = catalogue;");
                    connection.Open();
                    MySqlCommand sqlCmd1 = new MySqlCommand("SELECT Prix_Client FROM traverse_av WHERE Code=" + "'TRF" + items["Largeur"] + "'", connection);
                    MySqlDataReader myReader1 = sqlCmd1.ExecuteReader();

                    while (myReader1.Read())
                    {
                        price = myReader1.GetString(0);
                        price = Math.Round(Convert.ToDouble(price), 2).ToString("0.00").ToString();

                        total_price += Convert.ToDouble(price);
                        total_price = Convert.ToDouble(Math.Round(total_price, 2).ToString("0.00"));
                    }
                    connection.Close();

                    bill.Rows.Add(i, "TRF" + items["Largeur"], "Traverse AV", price, 2, 2* Convert.ToDouble(price));

                    //MySqlConnection connection2 = new MySqlConnection("server = localhost; uid = root; database = kitbox;");
                    //string insertQuery = "INSERT INTO orders(order_id, order_code, quantity) VALUES(NULL,'" + "TRF" + items["Largeur"] +"',"+ "'2'"+")";
                    //connection2.Open();
                    //MySqlCommand command = new MySqlCommand(insertQuery, connection2);

                    //if (command.ExecuteNonQuery() == 1)
                    //{

                    //}
                    //else
                    //{
                    //    MessageBox.Show("Data Not Inserted.", "Error",
                    //    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //}
                    //connection2.Close();
                }



                ////Add Cornières COR
                //if (items.ContainsKey("Hauteur_" + i) && items.ContainsKey("Largeur") && items.ContainsKey("Couleur_casier_" + i))
                //{
                //    MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; database = catalogue;");
                //    connection.Open();
                //    MySqlCommand sqlCmd1 = new MySqlCommand("SELECT Prix_Client FROM cornières WHERE Code=" + "'COR" + items["Hauteur_" + i] + items["Largeur"] + code_couleur_casier + "'", connection);
                //    MySqlDataReader myReader1 = sqlCmd1.ExecuteReader();

                //    while (myReader1.Read())
                //    {
                //        price = myReader1.GetString(0);
                //        total = Convert.ToDouble(nombre_casiers) * Convert.ToDouble(price);
                //        total_price += total;
                //    }
                //    connection.Close();

                //    bill.Rows.Add("COR" + items["Hauteur_" + i] + items["Largeur"] + code_couleur_casier, "Panneau Ar", price, nombre_casiers, total);
                //}

                //break;
            }

            bill.Rows.Add("", "", "", "Total:", total_price + " €");

            return bill;
        }
        #endregion

        #region Events
        void ExportDataTableToPdf(DataTable dtblTable, String strPdfPath, string strHeader)
        {
            System.IO.FileStream fs = new FileStream(strPdfPath, FileMode.Create, FileAccess.Write, FileShare.None);
            Document document = new Document();
            document.SetPageSize(iTextSharp.text.PageSize.A4);
            PdfWriter writer = PdfWriter.GetInstance(document, fs);
            document.Open();

            //Report Header
            BaseFont bfntHead = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            Font fntHead = new Font(bfntHead, 16, 1, Color.GRAY);
            Paragraph prgHeading = new Paragraph();
            prgHeading.Alignment = Element.ALIGN_CENTER;
            prgHeading.Add(new Chunk(strHeader.ToUpper(), fntHead));
            document.Add(prgHeading);

            //Time and Date
            Paragraph prgAuthor = new Paragraph();
            BaseFont btnAuthor = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            Font fntAuthor = new Font(btnAuthor, 8, 2, Color.GRAY);
            prgAuthor.Alignment = Element.ALIGN_RIGHT;
            prgAuthor.Add(new Chunk("Time: " + DateTime.Now.ToShortTimeString(), fntAuthor));
            prgAuthor.Add(new Chunk("\nDate: " + DateTime.Now.ToShortDateString(), fntAuthor));
            document.Add(prgAuthor);

            Paragraph prgAuthor2 = new Paragraph();
            BaseFont btnAuthor2 = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            Font fntAuthor2 = new Font(btnAuthor, 8, 2, Color.GRAY);
            prgAuthor2.Alignment = Element.ALIGN_LEFT;
            prgAuthor2.Add(new Chunk("Order No: 1", fntAuthor2));
            prgAuthor2.Add(new Chunk("\nCompany Name: KitBox", fntAuthor2));
            document.Add(prgAuthor2);

            //Add a line seperation
            Paragraph p = new Paragraph(new Chunk(new iTextSharp.text.pdf.draw.LineSeparator(0.0F, 100.0F, Color.BLACK, Element.ALIGN_LEFT, 1)));
            document.Add(p);

            //Add line break
            document.Add(new Chunk("\n", fntHead));

            //Write the table
            PdfPTable table = new PdfPTable(dtblTable.Columns.Count);
            //Table header
            BaseFont btnColumnHeader = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            Font fntColumnHeader = new Font(btnColumnHeader, 10, 1, Color.WHITE);
            for (int i = 0; i < dtblTable.Columns.Count; i++)
            {
                PdfPCell cell = new PdfPCell();
                cell.BackgroundColor = Color.GRAY;
                cell.AddElement(new Chunk(dtblTable.Columns[i].ColumnName.ToUpper(), fntColumnHeader));

                float[] widths = new float[] { 1.2f, 1.5f, 1.5f, 1f, 1f, 1f };
                table.SetWidths(widths);

                table.AddCell(cell);
            }
            //table Data
            for (int i = 0; i < dtblTable.Rows.Count; i++)
            {
                for (int j = 0; j < dtblTable.Columns.Count; j++)
                {
                    table.AddCell(dtblTable.Rows[i][j].ToString());
                }
            }

            document.Add(table);
            document.Close();
            writer.Close();
            fs.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cbxOpen_CheckedChanged(object sender, EventArgs e)
        {

        }
        #endregion

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.BackgroundImage = null;
            this.Controls.Clear();
            this.Controls.Add(new UILogin());
        }
    }
}