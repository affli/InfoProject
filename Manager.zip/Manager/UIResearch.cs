﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace KitBox.Manager
{
	public partial class UIResearch : UserControl
	{
		MySqlConnection connection = new MySqlConnection("server = localhost; uid = root; pwd = root; database = kitbox;");
		DataTable data = new DataTable();

		public UIResearch()
		{
			InitializeComponent();
			this.comboBox1.Items.Add("Stuff");
			this.comboBox1.Items.Add("Color");
			this.comboBox1.Items.Add("Height");
			this.comboBox1.Items.Add("Width");

		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void textBox7_TextChanged(object sender, EventArgs e)
		{

		}

		private void label7_Click(object sender, EventArgs e)
		{

		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.BackgroundImage = null;
			this.Controls.Clear();
			this.Controls.Add(new UIStocks());
		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{

		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{

		}

		private void label3_Click(object sender, EventArgs e)
		{

		}

		private void label2_Click(object sender, EventArgs e)
		{

		}

		private void label1_Click(object sender, EventArgs e)
		{

		}





		private void label4_Click(object sender, EventArgs e)
		{

		}

		private void pictureBox2_Click(object sender, EventArgs e)
		{
			this.BackgroundImage = null;
			this.Controls.Clear();
			this.Controls.Add(new UIStocks());
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
			this.BackgroundImage = null;
			this.Controls.Clear();
			this.Controls.Add(new LaunchScreen());
		}

		private void pictureBox3_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}


		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void textBox1_TextChanged_1(object sender, EventArgs e)
		{

			{
				connection.Open();
				if (comboBox1.Text == "Stuff")
				{
				
					MySqlDataAdapter msda = new MySqlDataAdapter("SELECT stuff,color,height,width FROM stock WHERE Stuff LIKE '" + textBox1.Text + "%'", connection);
					msda.Fill(data);
				}
				else if (comboBox1.Text == "Color")
				{
					
					MySqlDataAdapter msda = new MySqlDataAdapter("SELECT stuff,color,height,width FROM stock WHERE Color LIKE '" + textBox1.Text + "%'", connection);
					msda.Fill(data);
				}
				else if (comboBox1.Text == "Height")
				{
					
					MySqlDataAdapter msda = new MySqlDataAdapter("SELECT stuff,color,height,width FROM stock WHERE Height LIKE '" + textBox1.Text + "%'", connection);
					msda.Fill(data);
				}
				else if (comboBox1.Text == "Width")
				{
					
					MySqlDataAdapter msda = new MySqlDataAdapter("SELECT stuff,color,height,width FROM stock WHERE Width LIKE '" + textBox1.Text + "%'", connection);
					msda.Fill(data);
				}
				
				dataGridView1.DataSource = data;
				connection.Close();
			}
		}
	}
}
